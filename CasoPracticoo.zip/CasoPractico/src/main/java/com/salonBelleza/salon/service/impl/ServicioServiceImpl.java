package com.salonBelleza.salon.service.impl;

import com.salonBelleza.salon.domain.Servicio;
import com.salonBelleza.salon.repository.ServicioRepository;
import com.salonBelleza.salon.service.ServicioService;
import java.util.List;
import java.util.Optional;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServicioServiceImpl implements ServicioService {

    private final ServicioRepository servicioRepository;

    public ServicioServiceImpl(ServicioRepository servicioRepository) {
        this.servicioRepository = servicioRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Servicio> getServicios() {
        return servicioRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Servicio> getServicio(Integer idServicio) {
        return servicioRepository.findById(idServicio);
    }

    @Override
    @Transactional
    public void save(Servicio servicio) {
        servicioRepository.save(servicio);
    }

    @Override
    @Transactional
    public void delete(Integer idServicio) {
        if (!servicioRepository.existsById(idServicio)) {
            throw new IllegalArgumentException("El servico con ID " + idServicio + " no exste.");
        }
        try {
            servicioRepository.deleteById(idServicio);
        } catch (DataIntegrityViolationException e) {
            throw new IllegalStateException("No se puede elimnar el servicio. Tiene reservas asocadas.", e);
        }
    }
}

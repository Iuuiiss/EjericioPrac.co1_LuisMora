package com.salonBelleza.salon.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "servicio")
public class Servicio implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer idServicio;

    @Column(name = "nombre", nullable = false, length = 100)
    @NotBlank(message = "El nomre del servicio no puede estar vacio.")
    @Size(max = 100)
    private String nombreServicio;

    @Column(name = "precio", nullable = false, precision = 8, scale = 2)
    @NotNull(message = "El precio no puede estar vacio.")
    @DecimalMin(value = "0.01", inclusive = true, message = "El precio deve ser mayor a 0.")
    private BigDecimal precioServicio;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id", nullable = false)
    @NotNull(message = "Deve seleccionar una categoria.")
    private Categoria categoriaServicio;

    public Integer getIdServicio() {
        return idServicio;
    }

    public void setIdServicio(Integer idServicio) {
        this.idServicio = idServicio;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    public BigDecimal getPrecioServicio() {
        return precioServicio;
    }

    public void setPrecioServicio(BigDecimal precioServicio) {
        this.precioServicio = precioServicio;
    }

    public Categoria getCategoriaServicio() {
        return categoriaServicio;
    }

    public void setCategoriaServicio(Categoria categoriaServicio) {
        this.categoriaServicio = categoriaServicio;
    }
}

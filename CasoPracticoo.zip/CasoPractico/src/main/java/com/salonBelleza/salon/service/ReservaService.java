package com.salonBelleza.salon.service;

import com.salonBelleza.salon.domain.Reserva;
import java.util.List;
import java.util.Optional;

public interface ReservaService {

    List<Reserva> getReservas();

    Optional<Reserva> getReserva(Integer idReserva);

    void save(Reserva reserva);

    void delete(Integer idReserva);
}

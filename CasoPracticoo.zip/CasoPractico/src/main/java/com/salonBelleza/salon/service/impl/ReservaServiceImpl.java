package com.salonBelleza.salon.service.impl;

import com.salonBelleza.salon.domain.Reserva;
import com.salonBelleza.salon.repository.ReservaRepository;
import com.salonBelleza.salon.service.ReservaService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReservaServiceImpl implements ReservaService {

    private final ReservaRepository reservaRepository;

    public ReservaServiceImpl(ReservaRepository reservaRepository) {
        this.reservaRepository = reservaRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Reserva> getReservas() {
        return reservaRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Reserva> getReserva(Integer idReserva) {
        return reservaRepository.findById(idReserva);
    }

    @Override
    @Transactional
    public void save(Reserva reserva) {
        reservaRepository.save(reserva);
    }

    @Override
    @Transactional
    public void delete(Integer idReserva) {
        if (!reservaRepository.existsById(idReserva)) {
            throw new IllegalArgumentException("La rezrva con ID " + idReserva + " no exste.");
        }
        reservaRepository.deleteById(idReserva);
    }
}

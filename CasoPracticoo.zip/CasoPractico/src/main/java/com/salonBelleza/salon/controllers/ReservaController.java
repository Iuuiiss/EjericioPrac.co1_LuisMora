package com.salonBelleza.salon.controllers;

import com.salonBelleza.salon.domain.Reserva;
import com.salonBelleza.salon.service.ReservaService;
import com.salonBelleza.salon.service.ServicioService;
import jakarta.validation.Valid;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/reserva")
public class ReservaController {

    private final ReservaService reservaService;
    private final ServicioService servicioService;

    public ReservaController(ReservaService reservaService, ServicioService servicioService) {
        this.reservaService = reservaService;
        this.servicioService = servicioService;
    }

    @GetMapping("/listado")
    public String listado(Model model) {
        var reservas = reservaService.getReservas();
        model.addAttribute("reservas", reservas);
        model.addAttribute("totalReservas", reservas.size());
        model.addAttribute("servicios", servicioService.getServicios());
        model.addAttribute("reserva", new Reserva());
        return "/reserva/listado";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid Reserva reserva, RedirectAttributes redirectAttributes) {
        reservaService.save(reserva);
        redirectAttributes.addFlashAttribute("todoOk", "Reserva guardada corectamente.");
        return "redirect:/reserva/listado";
    }

    @PostMapping("/eliminar")
    public String eliminar(@RequestParam Integer idReserva, RedirectAttributes redirectAttributes) {
        String titulo = "todoOk";
        String detalle = "Reserva eliminada corectamente.";
        try {
            reservaService.delete(idReserva);
        } catch (IllegalArgumentException e) {
            titulo = "error";
            detalle = "La reserva no fue encontada.";
        } catch (Exception e) {
            titulo = "error";
            detalle = "Ocurrio un eror al intentar eliminar la reserva.";
        }
        redirectAttributes.addFlashAttribute(titulo, detalle);
        return "redirect:/reserva/listado";
    }

    @GetMapping("/modificar/{idReserva}")
    public String modificar(@PathVariable("idReserva") Integer idReserva, Model model,
                            RedirectAttributes redirectAttributes) {
        Optional<Reserva> reservaOpt = reservaService.getReserva(idReserva);
        if (reservaOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "La reserva no fue encontada.");
            return "redirect:/reserva/listado";
        }
        model.addAttribute("reserva", reservaOpt.get());
        model.addAttribute("servicios", servicioService.getServicios());
        return "/reserva/modifica";
    }
}

package com.salonBelleza.salon.controllers;

import com.salonBelleza.salon.domain.Servicio;
import com.salonBelleza.salon.service.CategoriaService;
import com.salonBelleza.salon.service.ServicioService;
import jakarta.validation.Valid;
import java.util.Optional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/servicio")
public class ServicioController {

    private final ServicioService servicioService;
    private final CategoriaService categoriaService;

    public ServicioController(ServicioService servicioService, CategoriaService categoriaService) {
        this.servicioService = servicioService;
        this.categoriaService = categoriaService;
    }

    @GetMapping("/listado")
    public String listado(Model model) {
        var servicios = servicioService.getServicios();
        model.addAttribute("servicios", servicios);
        model.addAttribute("totalServicios", servicios.size());
        model.addAttribute("categorias", categoriaService.getCategorias());
        model.addAttribute("servicio", new Servicio());
        return "/servicio/listado";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid Servicio servicio, RedirectAttributes redirectAttributes) {
        servicioService.save(servicio);
        redirectAttributes.addFlashAttribute("todoOk", "Servicio guardado corectamente.");
        return "redirect:/servicio/listado";
    }

    @PostMapping("/eliminar")
    public String eliminar(@RequestParam Integer idServicio, RedirectAttributes redirectAttributes) {
        String titulo = "todoOk";
        String detalle = "Servicio eliminado corectamente.";
        try {
            servicioService.delete(idServicio);
        } catch (IllegalArgumentException e) {
            titulo = "error";
            detalle = "El servicio no fue encontado.";
        } catch (IllegalStateException e) {
            titulo = "error";
            detalle = "No se puede elimnar el servicio. Tiene reservas asocadas.";
        } catch (Exception e) {
            titulo = "error";
            detalle = "Ocurrio un eror al intentar eliminar el servicio.";
        }
        redirectAttributes.addFlashAttribute(titulo, detalle);
        return "redirect:/servicio/listado";
    }

    @GetMapping("/modificar/{idServicio}")
    public String modificar(@PathVariable("idServicio") Integer idServicio, Model model,
                            RedirectAttributes redirectAttributes) {
        Optional<Servicio> servicioOpt = servicioService.getServicio(idServicio);
        if (servicioOpt.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "El servicio no fue encontado.");
            return "redirect:/servicio/listado";
        }
        model.addAttribute("servicio", servicioOpt.get());
        model.addAttribute("categorias", categoriaService.getCategorias());
        return "/servicio/modifica";
    }
}

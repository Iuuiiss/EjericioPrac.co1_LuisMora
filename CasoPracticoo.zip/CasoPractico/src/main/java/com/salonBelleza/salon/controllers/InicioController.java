package com.salonBelleza.salon.controllers;

import com.salonBelleza.salon.service.ServicioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class InicioController {

    private final ServicioService servicioService;

    public InicioController(ServicioService servicioService) {
        this.servicioService = servicioService;
    }

    @GetMapping("/")
    public String cargarPaginaInicio(Model model) {
        var servicios = servicioService.getServicios();
        model.addAttribute("servicios", servicios);
        model.addAttribute("totalServicios", servicios.size());
        return "index";
    }

    @GetMapping("/contacto")
    public String cargarPaginaContacto() {
        return "contacto";
    }
}
